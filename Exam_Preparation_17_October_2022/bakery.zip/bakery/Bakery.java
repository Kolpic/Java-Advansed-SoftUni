package bakery;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class Bakery {
    private String name;
    private int capacity;
    private List<Employee> employees;

    public Bakery(String name, int capacity) {
        this.name = name;
        this.capacity = capacity;
        this.employees = new ArrayList<>();
    }

    public void add(Employee employee){
        if (employees.size() < capacity){
            employees.add(employee);
        }
    }

    public boolean remove(String name){
       Employee employeeToRemove = employees.stream()
               .filter(e -> e.getName().equals(name))
               .findFirst()
               .orElse(null);

       if (employeeToRemove != null){
           employees.remove(employeeToRemove);
           return true;
       }else {
           return false;
       }
    }

    public Employee getOldestEmployee(){
        return employees.stream().max(Comparator.comparingInt(Employee::getAge)).orElse(null);
//        return Collections.max(employees, Comparator.comparingInt(Employee::getAge));
    }

    public Employee getEmployee(String name){
        return employees.stream()
                .filter(e -> e.getName().equals(name))
                .findAny()
                .orElse(null);
    }

    public int getCount(){
        return employees.size();
    }

    public String report(){
       StringBuilder sb = new StringBuilder();
       sb.append(String.format("Employees working at Bakery %s:%n",name));
       for (Employee em : employees){
           sb.append(em).append(System.lineSeparator());
       }
       return sb.toString();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    public List<Employee> getEmployees() {
        return employees;
    }

    public void setEmployees(List<Employee> employees) {
        this.employees = employees;
    }
}
