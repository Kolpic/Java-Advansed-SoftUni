package Lab_Defining_Classes;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int number = Integer.parseInt(scanner.nextLine());
        String command = scanner.nextLine();

        while (number > 0){
            String[] carParts = command.split("\\s+");
            String brand = carParts[0];
            String model = carParts[1];
            int horsePower = Integer.parseInt(carParts[2]);

            Car car = new Car(brand,model,horsePower);
            printCar(car);

            number--;
            if (number == 0){
                break;
            }
            command = scanner.nextLine();
        }
    }

    private static void printCar(Car car) {
        System.out.println(String.format("The car is: %s %s - %d HP.",
                car.getBrand(), car.getModel(), car.getHorsePower()));
    }
}
