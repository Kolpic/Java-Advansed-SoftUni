package Lab_Defining_Classes;

import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int number = Integer.parseInt(scanner.nextLine());
        String command = scanner.nextLine();
        List<Car> cars = new LinkedList<>();

        while (number > 0){
            String[] carParts = command.split("\\s+");
            String brand = carParts[0];

            if (carParts.length == 1){
                Car car = new Car(brand);
                cars.add(car);
            }else {
                Car car = new Car(brand,carParts[1],Integer.parseInt(carParts[2]));
                cars.add(car);
            }


            number--;
            if (number == 0){
                break;
            }
            command = scanner.nextLine();
        }
        for (Car car : cars){
            printCar(car);
        }
    }

    private static void printCar(Car car) {
        System.out.println(String.format("The car is: %s %s - %d HP.",
                car.getBrand(), car.getModel(), car.getHorsePower()));
    }
}
