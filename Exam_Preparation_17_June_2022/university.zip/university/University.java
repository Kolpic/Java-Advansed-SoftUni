package university;

import java.util.ArrayList;
import java.util.List;

public class University {
    public int capacity;
    public List<Student> students;

    public University(int capacity) {
        this.capacity = capacity;
        this.students = new ArrayList<>();
    }

    public int getCapacity() {
        return capacity;
    }

    public List<Student> getStudents() {
        return students;
    }

    public int getStudentCount() {
        return students.size();
    }

    public String registerStudent(Student student) {

        String result = null;

        if (students.size() >= capacity) {
            result =  "No seats in the university";

        }

        for (Student s : students) {
            if (s.getFirstName().equals(student.getFirstName())
                    && s.getLastName().equals(student.getLastName())){
                result =  "Student is already in the university";
            }
        }

        if (result == null) {
            students.add(student);
            result =  String.format("Added student %s %s", student.getFirstName(),student.getLastName());
        }

        return result;
    }

    public String dismissStudent(Student name) {
        String result = null;

        for (Student s : students) {
            if (s.getFirstName().equals(name.getFirstName())
                    && s.getLastName().equals(name.getLastName())){
                students.remove(s);
                result =  "Removed student " + name.firstName + " " + name.lastName;
                break;
            }else {
                result = "Student not found";
            }
        }
        return result;
//      if (students.contains(name)){
//          return "Removed student " + name.firstName + " " + name.lastName;
//      }else {
//          return "Student not found";
//      }
    }

    public Student getStudent(String firstName, String lastName) {
       return students.stream().filter(e -> e.getFirstName().equals(firstName)
                && e.getLastName().equals(lastName))
               .findFirst()
               .orElse(null);
    }
//	"==Student: First Name = {firstName}, Last Name = {lastName}, Best Subject = {bestSubject}
    public String getStatistics() {
        StringBuilder sb = new StringBuilder();
        for (Student student : students) {
            sb.append(String.format("==Student: First Name = %s," +
                    " Last Name = %s, Best Subject = %s"
                    , student.firstName,student.lastName,student.bestSubject))
                    .append(System.lineSeparator());
        }
        return sb.toString().trim();
    }
}
